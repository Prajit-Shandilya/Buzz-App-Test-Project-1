import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import AppHeader from '../components/AppHeader';

// You can import from local files


export default class Fbscreen extends React.Component{
  render(){
  return (
    <View>
   <AppHeader/>
      <Text style={{fontSize:540}}>
      This is Facebook Screen.
      </Text>
     
    </View>
  );
}
}

