import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import AppHeader from '../components/AppHeader';

// You can import from local files


export default class Homescreen extends React.Component{
  render(){
  return (
    <View>
   <AppHeader/>
      <Text style={styles.paragraph}>
      Welcome To The Buzz App
      </Text>
    </View>
  );
}
}
const styles = StyleSheet.create({
 /* container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },*/
  paragraph: {
    margin: 24,
    fontSize: 58,
    fontWeight: 'bold',
    textAlign: 'center',
  }
});