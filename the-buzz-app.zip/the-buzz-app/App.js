import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import Fbscreen from './screens/Fbscreen';
import Inscreen from './screens/Inscreen';
import AppHeader from './components/AppHeader';
import Homescreen from './screens/Homescreen'
import { createAppContainer } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';

// You can import from local files

export default class App extends React.Component{
  render(){
  return (
   <View>
      <AppHeader />
      <AppContainer />
       <Text style={styles.paragraph}>
      Welcome To The Buzz App
      </Text>
    </View>
  );
}
}



const styles = StyleSheet.create({
  /* container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },*/
  paragraph: {
  margin: 24,
  fontSize: 58,
   fontWeight: 'bold',
   textAlign: 'center',
   }
});

const TabNavigator = createBottomTabNavigator({
  Home:{screen:Homescreen},
  Facebook: { screen: Fbscreen },
  Instagram: { screen: Inscreen },
  
});

const AppContainer = createAppContainer(TabNavigator);
