import * as React from 'react';
import {Text,View,StyleSheet} from 'react-native';

class AppHeader extends React.Component{
  render(){
    return(
    <View style={mystyle.textContainer}>
    <Text style={mystyle.text}>The Buzz App</Text>
    </View>
    );
  }

  
}

const mystyle = StyleSheet.create({
textContainer:{
  backgroundColor:'yellow',

},
text:{
  color:'blue',
  fontSize:'50px',
  fontWeight:'bold',
  textAlign:'center',
  border:'solid'
}
});

export default AppHeader;
